import { Text } from "@chakra-ui/react";

function App() {
  return (
    <div>
      <Text color={"red.500"} fontSize={"6xl"}>
        It works!!!!!
      </Text>      
    </div>
  );
}

export default App;
